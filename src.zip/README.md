# Graduation work
## Multi-agent graph exploration without communication

Ongoing...

## To run an example
_python3 my.py 3 test1_

Thanks for @MAN1986 for provide the code base 

